#ifndef PHOTO_GALLERY_IMAGES_H
#define PHOTO_GALLERY_IMAGES_H
extern const unsigned char *images_for_photo_gallery[];
#endif